# WebView JavaScript interface rules (kept in case you add @JavascriptInterface methods later)
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}
-dontwarn android.webkit.**
